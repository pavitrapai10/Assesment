# FileHub
full-stack, CRUD-capable, and responsive web application using Node.js and React. Build a user authorization system using the JSON Web Token (JWT). Add database functionality with MongoDB fitting into the Express application framework. 
<img width="1404" alt="Screenshot 2023-07-27 at 6 43 25 PM" src="https://github.com/QTUQ/FileHub/assets/112546397/338cfa12-2a40-4e94-9263-7d608f2d214d">
<img width="1401" alt="Screenshot 2023-07-27 at 6 42 33 PM" src="https://github.com/QTUQ/FileHub/assets/112546397/777ada12-e696-495b-961c-767a0b868fcc">
